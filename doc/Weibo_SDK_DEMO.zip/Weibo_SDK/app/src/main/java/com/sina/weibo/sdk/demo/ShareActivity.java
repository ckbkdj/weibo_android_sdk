package com.sina.weibo.sdk.demo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;
import android.widget.VideoView;

import com.sina.weibo.sdk.demo.R;
import com.sina.weibo.sdk.api.ImageObject;
import com.sina.weibo.sdk.api.MultiImageObject;
import com.sina.weibo.sdk.api.SuperGroupObject;
import com.sina.weibo.sdk.api.TextObject;
import com.sina.weibo.sdk.api.VideoSourceObject;
import com.sina.weibo.sdk.api.WebpageObject;
import com.sina.weibo.sdk.api.WeiboMultiMessage;
import com.sina.weibo.sdk.auth.AuthInfo;
import com.sina.weibo.sdk.common.UiError;
import com.sina.weibo.sdk.demo.util.UIUtils;
import com.sina.weibo.sdk.openapi.IWBAPI;
import com.sina.weibo.sdk.openapi.WBAPIFactory;
import com.sina.weibo.sdk.share.WbShareCallback;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

public class ShareActivity extends Activity implements View.OnClickListener, WbShareCallback {

    public static final int REQUEST_CODE = 1010;
    public static final int REQ_PICK_IMAGE_COMPOSER = 191235;
    public static final int REQ_PICK_VIDEO_COMPOSER = 191237;
    private CheckBox mShareText;

    private CheckBox mShareImage;

    private CheckBox mShareUrl;

    private CheckBox mShareMultiImage;

    private CheckBox mShareVideo;

    private CheckBox mShareSuperGroup;

    private CheckBox mShareMediaImg, mShareMediaVideo;

    private RadioButton mShareClientOnly;

    private RadioButton mShareClientH5;

    private View superGroupConfigLayout;

    private Button mCommitBtn;

    private IWBAPI mWBAPI;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UIUtils.setContentViewAndSetWindowInsets(this, R.layout.activity_share);
        mShareText = findViewById(R.id.share_text_cb);
        mShareImage = findViewById(R.id.share_image_cb);
        mShareUrl = findViewById(R.id.share_url_cb);
        mShareMultiImage = findViewById(R.id.share_multi_image_cb);
        mShareVideo = findViewById(R.id.share_video_cb);
        mShareSuperGroup = findViewById(R.id.share_super_group);
        mShareClientOnly = findViewById(R.id.share_client_only);
        mShareClientH5 = findViewById(R.id.share_client_h5);
        mShareMediaImg = findViewById(R.id.share_media_img);
        mShareMediaVideo = findViewById(R.id.share_media_video);
        mCommitBtn = findViewById(R.id.commit);
        mCommitBtn.setOnClickListener(this);
        mWBAPI = WBAPIFactory.createWBAPI(this);
        mWBAPI.setLoggerEnable(true);

        superGroupConfigLayout = findViewById(R.id.sg_config_layout);
        mShareSuperGroup.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                superGroupConfigLayout.setVisibility(isChecked ? View.VISIBLE : View.GONE);
            }
        });
    }

    private void openGallery(int requestCode,boolean video) {
        Intent intent;
        if (video) {
            if (Build.VERSION.SDK_INT >= 33) {
                intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
            }else {
                intent = new Intent(Intent.ACTION_PICK);
                intent.setType("video/*");
            }
        } else {
            if (Build.VERSION.SDK_INT >= 33) {
                intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            }else {
                intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
            }
        }
        startActivityForResult(intent, requestCode);
    }

    @Override
    public void onClick(View v) {
        if (v == mCommitBtn) {
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.M && !isPermissionGranted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                //Android 6.0需申请SD卡权限后才能分享
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE);
            } else {
                doWeiboShare();
            }
        }
    }

    private boolean isPermissionGranted(String permission) {
        try {
            return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                doWeiboShare();
            }
        }else {
            Toast.makeText(ShareActivity.this, "缺少权限", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mWBAPI.isShareResult(requestCode, resultCode, data)) {
            mWBAPI.doResultIntent(data, this);
        } else if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            if (requestCode == REQ_PICK_IMAGE_COMPOSER) {
                doWeiboShareImage(imageUri);
            } else if (requestCode == REQ_PICK_VIDEO_COMPOSER) {
                doWeiboShareVideo(imageUri);
            }
        }
    }

    private void doWeiboShareImage(Uri uri) {
        WeiboMultiMessage message = new WeiboMultiMessage();
        TextObject textObject = new TextObject();
        String text = "我正在使用微博客户端发博器分享文字。";
        // 分享文字
        if (mShareText.isChecked()) {
            text = "这里设置您要分享的内容！";
            textObject.text = text;
            message.textObject = textObject;
        }

        // 分享多图
        MultiImageObject multiImageObject = new MultiImageObject();
        ArrayList<Uri> list = new ArrayList<>();
        list.add(uri);
        multiImageObject.imageList = list;
        message.multiImageObject = multiImageObject;
        mWBAPI.shareMessage(this, message, true);
    }


    private void doWeiboShareVideo(Uri uri) {
        WeiboMultiMessage message = new WeiboMultiMessage();
        TextObject textObject = new TextObject();
        String text = "我正在使用微博客户端发博器分享文字。";
        // 分享文字
        if (mShareText.isChecked()) {
            text = "这里设置您要分享的内容！";
            textObject.text = text;
            message.textObject = textObject;
        }
        VideoSourceObject videoObject = new VideoSourceObject();
        videoObject.videoPath = uri;
        message.videoSourceObject = videoObject;
        mWBAPI.shareMessage(this, message, mShareClientOnly.isChecked());
    }

    private void doWeiboShare() {
        //相册-照片
        if (mShareMediaImg.isChecked()) {
            openGallery(REQ_PICK_IMAGE_COMPOSER, false);
            return;
        }
        //相册-视频
        if (mShareMediaVideo.isChecked()) {
            openGallery(REQ_PICK_VIDEO_COMPOSER, true);
            return;
        }
        WeiboMultiMessage message = new WeiboMultiMessage();

        TextObject textObject = new TextObject();
        String text = "我正在使用微博客户端发博器分享文字。";

        // 分享文字
        if (mShareText.isChecked()) {
            text = "这里设置您要分享的内容！";
            textObject.text = text;
            message.textObject = textObject;
        }

        // 分享图片
        if (mShareImage.isChecked()) {
            ImageObject imageObject = new ImageObject();
            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.share_image);
            imageObject.setImageData(bitmap);
            if (!imageObject.checkArgs()) {
                Toast.makeText(ShareActivity.this, "imageObject is too large", Toast.LENGTH_SHORT).show();
                return;
            }
            message.imageObject = imageObject;
        }

        // 分享网页
        if (mShareUrl.isChecked()) {
            WebpageObject webObject = new WebpageObject();
            webObject.identify = UUID.randomUUID().toString();
            webObject.title = "标题";
            webObject.description = "描述";
            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_logo);
            ByteArrayOutputStream os = null;
            try {
                os = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, os);
                webObject.thumbData = os.toByteArray();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (os != null) {
                        os.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            webObject.actionUrl = "https://weibo.com";
            webObject.defaultText = "分享网页";
            message.mediaObject = webObject;
        }

        if (mShareMultiImage.isChecked()) {
            // 分享多图
            MultiImageObject multiImageObject = new MultiImageObject();
            ArrayList<Uri> list = new ArrayList<>();
            File externalFilesDir = getExternalFilesDir(null);
            File externalCacheDir = getExternalCacheDir();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                String authority = this.getPackageName() + ".wbsdk.fileprovider";
                list.add(FileProvider.getUriForFile(this, authority, new File(externalFilesDir, "aaa.png")));
                list.add(FileProvider.getUriForFile(this, authority, new File(externalCacheDir, "bbb.jpg")));
                list.add(FileProvider.getUriForFile(this, authority, new File(externalFilesDir + "/file_images/ccc.JPG")));
                list.add(FileProvider.getUriForFile(this, authority, new File(externalFilesDir + "/cache_images/ddd.jpg")));
                list.add(FileProvider.getUriForFile(this, authority, new File(externalCacheDir + "/file_images/eee.jpg")));
                list.add(FileProvider.getUriForFile(this, authority, new File(externalFilesDir + "/file_images/fff.jpg")));
                list.add(FileProvider.getUriForFile(this, authority, new File(externalFilesDir+"/file_images/ggg.JPG")));
                list.add(FileProvider.getUriForFile(this, authority, new File(externalFilesDir + "/file_images/hhhh.jpg")));
            } else {
                list.add(Uri.fromFile(new File(externalFilesDir, "aaa.png")));
                list.add(Uri.fromFile(new File(externalCacheDir, "bbb.jpg")));
                list.add(Uri.fromFile(new File(externalFilesDir + "/file_images/ccc.JPG")));
                list.add(Uri.fromFile(new File(externalFilesDir + "/cache_images/ddd.jpg")));
                list.add(Uri.fromFile(new File(externalCacheDir + "/file_images/eee.jpg")));
                list.add(Uri.fromFile(new File(externalFilesDir + "/file_images/fff.jpg")));
                list.add(Uri.fromFile(new File(externalFilesDir+"/file_images/ggg.JPG")));
                list.add(Uri.fromFile(new File(externalFilesDir + "/file_images/hhhh.jpg")));
            }
            multiImageObject.imageList = list;
            message.multiImageObject = multiImageObject;
        }

        if (mShareVideo.isChecked()) {
            // 分享视频
            VideoSourceObject videoObject = new VideoSourceObject();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                String filePath = getExternalFilesDir(null) + "/file_video/eeee.mp4";
                File videoFile = new File(filePath);
                if (!videoFile.getParentFile().exists()) {
                    videoFile.getParentFile().mkdir();
                }
                videoObject.videoPath = FileProvider.getUriForFile(this, this.getPackageName() + ".wbsdk.fileprovider", videoFile);
            } else {
                videoObject.videoPath = Uri.fromFile(new File(getExternalFilesDir(null) + "/file_video/eeee.mp4"));
            }
            message.videoSourceObject = videoObject;
        }

        if (mShareSuperGroup.isChecked()) {
            //	如果想要拉起超话类型发布器需要传superGroupobject对象
            SuperGroupObject superGroupObject = new SuperGroupObject();
            /**
             *  超话名，可以传可以不传
             * 	1、如果不传该参数则拉起选择超话弹层
             * 	2、如果传该参数，不出选择超话弹层，直接选中超话
             */
            String sgName = ((EditText) findViewById(R.id.edit_sg_name)).getText().toString().trim();
            if (TextUtils.isEmpty(sgName)) {
                sgName = this.getString(R.string.demo_sg_name);
            }
            superGroupObject.sgName = sgName;
            // 超话板块，可以传可以不传
            String sgSection = ((EditText)findViewById(R.id.edit_sg_section)).getText().toString().trim();
            superGroupObject.secName = sgSection;
            // 扩展参数，需要透传的信息加在这个参数里
            String sgExt = ((EditText) findViewById(R.id.edit_sg_ext)).getText().toString().trim();
            superGroupObject.sgExtParam = sgExt;
            message.superGroupObject = superGroupObject;
        }

        mWBAPI.shareMessage(this, message, mShareClientOnly.isChecked());
    }

    @Override
    public void onComplete() {
        Toast.makeText(ShareActivity.this, "分享成功", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError(UiError error) {
        Toast.makeText(ShareActivity.this, "分享失败:" + error.errorMessage, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCancel() {
        Toast.makeText(ShareActivity.this, "分享取消", Toast.LENGTH_SHORT).show();
    }
}
